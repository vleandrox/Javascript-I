//iniciar un objeto
const product1 = {
    nombre: "Laptop",
    precio: 1000,
    stock: 2
}

//Agregar propiedades
product1["id"] = "00001";
product1["marca"] = "HP";
product1.foto = "https://granhogar.com.ec/imagenes/productos/7988:49:d0?v=0";

//Imprimir por consola
console.log(product1);