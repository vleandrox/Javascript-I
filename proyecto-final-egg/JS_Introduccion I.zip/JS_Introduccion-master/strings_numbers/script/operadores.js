const num1 = 100;
const num2 = 20;
const num3 = 5;

/* suma de numeros */
const suma = num1 + num2 + num3;
console.log(suma);

/* resta de numeros */
const resta = suma - num1 - 50;
console.log(resta);

/* multiplicacion de numeros */
const multiplicacion = resta * 2 * (-1) * 4.25;
console.log(multiplicacion);

/* division de numeros */
const division = (suma/num2)/5;
console.log(division);

const operaciones = (num1 + num2) * (num2 + num3) / (suma - resta);
console.log(operaciones);