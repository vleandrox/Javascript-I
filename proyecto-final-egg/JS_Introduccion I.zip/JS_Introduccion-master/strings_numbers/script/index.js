const numero = 100;
console.log(numero);
console.log(typeof numero);

const cadena = "Cadena de texto";
console.log(cadena);
console.log(typeof cadena);
console.log("La longitud de la variable cadena es: " + cadena.length);

const booleano = true;
console.log(booleano);
console.log(typeof booleano);

/* saber la longitud de la cadena de texto */
const nuevaCadena = "Hallar la longitud de esta cadena";
console.log(nuevaCadena.length);